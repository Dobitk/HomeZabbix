ifconfig ra0 down
rmmod mtnet7601Usta
rmmod mt7601Usta
rmmod mtutil7601Usta
lsmod | grep "mt7601"